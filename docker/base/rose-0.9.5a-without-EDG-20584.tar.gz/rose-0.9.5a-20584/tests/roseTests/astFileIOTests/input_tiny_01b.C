// Empty file required for input_tiny_01 test.
