// If this is uncommented then the 
// SgPointerType's will match in the 
// merge and the merge will happen 
// correctly.
// typedef char *__caddr_tXXX;

typedef char *__caddr_t;
