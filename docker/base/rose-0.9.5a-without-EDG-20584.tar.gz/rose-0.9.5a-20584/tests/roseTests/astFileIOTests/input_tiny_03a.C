
// char* __builtin_strchr (char *__builtin__s);
char *__builtin__s;

// void open_memstream (char **__bufloc);
// void open_memstream (char **__bufloc);
char **__bufloc;
