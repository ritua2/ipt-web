
// char* __builtin_strchr (char *__builtin__s);
char *__builtin__s;
