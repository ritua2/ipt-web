int foo() {
  return 7;
}

int main(int, char**) {
  int x = foo();
  return 0;
}
