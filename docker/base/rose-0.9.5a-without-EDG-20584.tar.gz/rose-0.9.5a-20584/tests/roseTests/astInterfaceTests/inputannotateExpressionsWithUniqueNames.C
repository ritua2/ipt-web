struct a {
  int b;  
};

namespace ns1{
  int a; 
  class ca 
  {
    static float b;
   } ;
}

extern void bar(float );
int foo(int x, int y)
{
  int z;
  z = x + y*2;
  return z;
}

