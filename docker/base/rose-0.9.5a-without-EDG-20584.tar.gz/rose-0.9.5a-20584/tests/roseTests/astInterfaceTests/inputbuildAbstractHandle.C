int a[10];
int main()
{
  int i=0;
  for (i=0;i<10;i++)
    a[i]=0;
  return 0;
}
