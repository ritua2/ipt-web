#ifdef __cplusplus
extern "C" {
#endif

extern int foo(double x);
extern int bar(double x);


#ifdef __cplusplus
 }
#endif
