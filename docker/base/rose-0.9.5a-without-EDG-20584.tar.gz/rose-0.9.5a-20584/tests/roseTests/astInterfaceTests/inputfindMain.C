namespace A {

int main(void)
{
  return 0;
}

}

int main(int argc, char* argv[])
{
  A::main();
  return 0;
}
