// Example contributed by Naoya Maruyama, 1/5/2012

typedef struct {
  int x;
} s;

int foo(s *a) {
  return a->x ;
}
