// Introduce a variable so that we can require this to appear before a statement inserted
// before the statement that has the include directive that defines this variable.
int variable_hidden_in_header_file;
