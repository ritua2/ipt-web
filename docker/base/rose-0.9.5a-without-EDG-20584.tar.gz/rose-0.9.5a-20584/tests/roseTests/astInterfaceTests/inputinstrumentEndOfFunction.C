extern int foo();
extern int call1();
int main(int argc, char* argv[])
{
  if (argc>1)
    return foo();
  else
     return foo();
  return 0;
}
