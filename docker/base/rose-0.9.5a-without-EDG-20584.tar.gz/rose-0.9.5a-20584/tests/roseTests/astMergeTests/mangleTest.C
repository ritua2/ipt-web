#include "mangleTest.h"

//This code tests the mangling of function names in classes

int main() {
 
  testing y;
  int x;
  while (true) {
    int x;
  }
  
  y.foo();
  
}
