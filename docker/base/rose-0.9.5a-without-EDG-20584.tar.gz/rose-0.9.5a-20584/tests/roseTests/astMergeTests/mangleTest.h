extern int q;

class testing {

public:

  int x, y;

  int foo();

  class blap {
  };
};

namespace blargh {
  int foo();
  namespace dude {
    int bar();
  }
}

