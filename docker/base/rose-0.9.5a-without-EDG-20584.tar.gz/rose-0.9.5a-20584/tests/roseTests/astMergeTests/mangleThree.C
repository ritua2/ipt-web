#include "mangleTest.h"

int testing::foo() {
  return 3;
}
