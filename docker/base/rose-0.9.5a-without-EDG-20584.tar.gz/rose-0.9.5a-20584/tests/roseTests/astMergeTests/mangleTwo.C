#include "mangleTwo.h"

// This code tests the mangling of function names in classes

double test() {

  return 4.8;
}
