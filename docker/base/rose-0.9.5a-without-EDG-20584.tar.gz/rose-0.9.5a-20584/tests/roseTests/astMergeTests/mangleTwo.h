namespace blargh {
  int foo();
  int bar();
  namespace dude {
    int bar();
  }
}
