void foo()
{
  int i,sum=0;
  for (i=0;i<100;i++)
  {
    sum +=i;
  }
}

