int main() {
    int m;
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            for (int k = 0; k < 5; k++) {
                for (int l = 0; l < 5; l++) {
//                    for (int q = 0; q < 6; q++) {
//                        for (int r = 0; r < 6; r++) {
                            m++;
//                        }
//                    }
                }
            }
        }
    }
    return 0;
}
