int main()
{
int x = 0;
if (true) {
    for (int i = 0; i < 10; i++) {
        x++;
    }
}
else {
    return 1;
}
return 0;
}
