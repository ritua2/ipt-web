int main() {
    int z = 0;
    int y = 0;
    int x = 0;
    if (z == 0) {
        x = 1;
    }
    else if (y == 0) {
        x = 1;
    }
    else {
        x = 0;
    }
    return x;
}
