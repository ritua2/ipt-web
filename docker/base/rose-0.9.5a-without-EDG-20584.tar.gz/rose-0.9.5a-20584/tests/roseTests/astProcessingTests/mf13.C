int main() {
    int w = 0;
    for (int i = 0; i < 8; i = i + 1) {
        //if (i < 5) {
            for (int q = 0; q < 8; q = q + 1) {
                w = w + 1;
            }
       // }
       // else {
            for (int k = 0; k < 8; k = k + 1) {
                w = w+1;
            }
       // }
    }
    return 1;
}
           
