int bounce(int x) {
   return x;
}

int main() {
   if (bounce(1) == 1) {
       return 1;
   }
   else {
       return 2;
    }
}
