//#include <iostream>
//#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char* argv[]) {
 //   ROSE_ASSERT(argc == 2);
    //char* argu = argv[1];
   
    int i;
    i  = atoi((const char*) '1');
    if (i > 2) {
        i = 3;
    }
    else {
        i = 2;
    }
    return 0;
}
