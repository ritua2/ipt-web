int main() {
    int i = 0;
    int x = 0;
    int ret;
    while (x < 7) {
        i = i + 2;
       // i = i + 1;
    }
    if (i > 12) {
        ret = i;
    }
   // else {
        return ret;
   // }
}
