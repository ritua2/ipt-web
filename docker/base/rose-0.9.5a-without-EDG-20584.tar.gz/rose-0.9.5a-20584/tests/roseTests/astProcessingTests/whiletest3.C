

int main() {
   // int i = 0;
    int x = 0;
    while (x<5) {//int i = 0; i < 5; i++) {// (x < 5) {
        //i = i + 2;
	x = x + 1;
       // i = i + 1;
    }
/*
    if (i > 15) {
        if (true) {
             i = i - 2;
        }
        else {
            i = i + 2;
        }
    }
*/
    //else {
        return 0;
   // }
}
