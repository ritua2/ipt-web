// This is a trival class with a constructor so that I can debug Brian's TauPreprocessor
class TauTimer
   {
      int x;
      int y;
      public:
      // Full function definition provided so that we can 
      // compile and link resulting instumented file.
         TauTimer() { /* call clock or whatever */ };
   };

