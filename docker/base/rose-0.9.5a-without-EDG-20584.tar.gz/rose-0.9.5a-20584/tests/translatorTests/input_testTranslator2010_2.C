int main()
{
      for(int i = 1;;i++);
      int a = 0;
      if(a==0) a = 1; // printf("a=0");

      return 0;
}
