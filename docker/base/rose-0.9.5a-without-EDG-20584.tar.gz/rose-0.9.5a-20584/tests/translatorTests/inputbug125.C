#include<string>

int main()
{
  return 0;
}
