# include <stdlib.h>
# include <stdio.h>
# include <time.h>
#include <sys/types.h>
#include <sys/time.h>

# define N 23
# define TIME_SIZE 40


int circuit_value ( int n, int bvec[] );
void i4_to_bvec ( int i4, int n, int bvec[] );
void timestamp ( void );
double gettime(void);

int main ( int argc, char *argv[] ){
  int bvec[N];
  int i;
  int ihi;
  int j;
  int n = N;
  int solution_num;
  int value;
  double wtime1, wtime2;


  printf ( "\n" );
  timestamp ( );
  printf ( "\n" );


  ihi = 1;
  for ( i = 1; i <= n; i++ ){
    ihi = ihi * 2;
  }


  solution_num = 0;

  wtime1 = gettime();
  for ( i = 0; i < ihi; i++ ){
    i4_to_bvec ( i, n, bvec );

    value = circuit_value ( n, bvec );

    if ( value == 1 ){
      solution_num = solution_num + 1;

      //printf ( "  %2d  %10d:  ", solution_num, i );
      for ( j = 0; j < n; j++ ){
        //printf ( " %d", bvec[j] );
      }
      //printf ( "\n" );
    }
  }

  wtime2 = gettime();

  printf ( "\n" );
  printf ( "  Number of solutions found was %d\n", solution_num );
  printf ( "  Elapsed wall clock time (seconds) %f\n", (wtime2 - wtime1) );

  printf ( "\n" );
  timestamp ( );
  printf ( "\n" );

  return 0;
}



int circuit_value ( int n, int bvec[] ){
  int value;

  value =
       (  bvec[0]  ||  bvec[1]  )
    && ( !bvec[1]  || !bvec[3]  )
    && (  bvec[2]  ||  bvec[3]  )
    && ( !bvec[3]  || !bvec[4]  )
    && (  bvec[4]  || !bvec[5]  )
    && (  bvec[5]  || !bvec[6]  )
    && (  bvec[5]  ||  bvec[6]  )
    && (  bvec[6]  || !bvec[15] )
    && (  bvec[7]  || !bvec[8]  )
    && ( !bvec[7]  || !bvec[13] )
    && (  bvec[8]  ||  bvec[9]  )
    && (  bvec[8]  || !bvec[9]  )
    && ( !bvec[9]  || !bvec[10] )
    && (  bvec[9]  ||  bvec[11] )
    && (  bvec[10] ||  bvec[11] )
    && (  bvec[12] ||  bvec[13] )
    && (  bvec[13] || !bvec[14] )
    && (  bvec[14] ||  bvec[15] )
    && (  bvec[14] ||  bvec[16] )
    && (  bvec[17] ||  bvec[1]  )
    && (  bvec[18] || !bvec[0]  )
    && (  bvec[19] ||  bvec[1]  )
    && (  bvec[19] || !bvec[18] )
    && ( !bvec[19] || !bvec[9]  )
    && (  bvec[0]  ||  bvec[17] )
    && ( !bvec[1]  ||  bvec[20] )
    && ( !bvec[21] ||  bvec[20] )
    && ( !bvec[22] ||  bvec[20] )
    && ( !bvec[21] || !bvec[20] )
    && (  bvec[22] || !bvec[20] );

  return value;
}


void i4_to_bvec ( int i4, int n, int bvec[] ){
  int i;

  for ( i = n - 1; 0 <= i; i-- )
  {
    bvec[i] = i4 % 2;
    i4 = i4 / 2;
  }

  return;
}



void timestamp ( void ){
  static char time_buffer[TIME_SIZE];
  const struct tm *tm;
  size_t len;
  time_t now;

  now = time ( NULL );
  tm = localtime ( &now );

  len = strftime ( time_buffer, TIME_SIZE, "%d %B %Y %I:%M:%S %p", tm );

  printf ( "%s\n", time_buffer );

  return;
}


double gettime(void) {
    struct timeval tval;
        gettimeofday(&tval, NULL);
        return( (double)tval.tv_sec + (double)tval.tv_usec/1000000.0 );
}

